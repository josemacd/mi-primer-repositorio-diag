
import React, { useState, useCallback, useMemo } from 'react';
import { AppView, Student, Answers, Question } from './types';
import { QUIZ_QUESTIONS } from './constants';
import Dashboard from './components/Dashboard';
import ModuleView from './components/ModuleView';
import QuizForm from './components/QuizForm';
import Quiz from './components/Quiz';
import QuizResults from './components/QuizResults';
import { WrenchIcon } from './components/Icons';

const TOTAL_QUIZZES = 4; // 3 mini-quizzes + 1 final quiz
const FINAL_QUIZ_KEY = "finalQuiz";

function App() {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [student, setStudent] = useState<Student | null>(null);
  const [answers, setAnswers] = useState<Answers>({});
  const [timeTaken, setTimeTaken] = useState(0);
  const [quizQuestions, setQuizQuestions] = useState<Question[]>([]);
  
  const [completedQuizzes, setCompletedQuizzes] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('completedQuizzes');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch (error) {
      console.error("Failed to parse completed quizzes from localStorage", error);
      return new Set();
    }
  });

  const courseProgress = useMemo(() => {
    return Math.round((completedQuizzes.size / TOTAL_QUIZZES) * 100);
  }, [completedQuizzes]);

  const markQuizAsCompleted = useCallback((quizKey: string) => {
    setCompletedQuizzes(prev => {
      const newSet = new Set(prev);
      newSet.add(quizKey);
      localStorage.setItem('completedQuizzes', JSON.stringify(Array.from(newSet)));
      return newSet;
    });
  }, []);

  const handleStartQuiz = useCallback((studentData: Student) => {
    setStudent(studentData);
    
    const shuffled = [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random());
    const selectedQuestions = shuffled.slice(0, 20);

    const questionsWithShuffledOptions = selectedQuestions.map(q => {
        const options = [...q.options];
        const correctAnswerValue = options[q.correctAnswer];
        
        for (let i = options.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [options[i], options[j]] = [options[j], options[i]];
        }
        
        const newCorrectAnswerIndex = options.findIndex(opt => opt === correctAnswerValue);

        return {
            ...q,
            options,
            correctAnswer: newCorrectAnswerIndex,
        };
    });

    setQuizQuestions(questionsWithShuffledOptions);
    setView(AppView.QUIZ_ACTIVE);
  }, []);
  
  const handleFinishQuiz = useCallback((finalAnswers: Answers, quizTime: number) => {
    setAnswers(finalAnswers);
    setTimeTaken(quizTime);
    markQuizAsCompleted(FINAL_QUIZ_KEY);
    setView(AppView.QUIZ_RESULTS);
  }, [markQuizAsCompleted]);

  const handleRestart = useCallback(() => {
    setStudent(null);
    setAnswers({});
    setTimeTaken(0);
    setQuizQuestions([]);
    setView(AppView.DASHBOARD);
  }, []);
  
  const renderView = () => {
    switch (view) {
      case AppView.MODULE:
        return <ModuleView onBack={() => setView(AppView.DASHBOARD)} markQuizAsCompleted={markQuizAsCompleted} />;
      case AppView.QUIZ_FORM:
        return <QuizForm onStartQuiz={handleStartQuiz} />;
      case AppView.QUIZ_ACTIVE:
        return <Quiz questions={quizQuestions} onFinish={handleFinishQuiz} />;
      case AppView.QUIZ_RESULTS:
        if (student) {
          return <QuizResults student={student} questions={quizQuestions} answers={answers} timeTaken={timeTaken} onRestart={handleRestart} />;
        }
        return <Dashboard onNavigateToModule={() => setView(AppView.MODULE)} onNavigateToQuiz={() => setView(AppView.QUIZ_FORM)} courseProgress={courseProgress} />;
      case AppView.DASHBOARD:
      default:
        return <Dashboard onNavigateToModule={() => setView(AppView.MODULE)} onNavigateToQuiz={() => setView(AppView.QUIZ_FORM)} courseProgress={courseProgress} />;
    }
  };

  return (
    <div className="min-h-screen bg-mec-light-gray dark:bg-mec-carbon text-mec-carbon dark:text-mec-light-gray font-sans">
      <header className="bg-white dark:bg-mec-blue/10 shadow-md no-print">
        <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <WrenchIcon className="h-8 w-8 text-mec-orange" />
            <h1 className="ml-3 text-xl font-bold text-mec-carbon dark:text-white">Diagnóstico y Afinamiento Electrónico</h1>
          </div>
          <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
            <img src='https://i.postimg.cc/GpsrQJ25/logo-senati-2.jpg' alt='logo-senati-2' className="h-16 border-0" />
          </a>
        </nav>
      </header>
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderView()}
      </main>
      <footer className="text-center py-4 mt-8 border-t border-mec-blue/10 no-print">
        <p className="text-sm text-mec-gray dark:text-gray-500">&copy; {new Date().getFullYear()} Diagnóstico y Afinamiento Electrónico del Motor. Elaborado por el Inst. José Céspedes Diaz.</p>
      </footer>
    </div>
  );
}

export default App;