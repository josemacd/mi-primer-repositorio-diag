
import React from 'react';
import Card from './shared/Card';
import { ToolboxIcon, ChartBarIcon, WrenchIcon } from './Icons';

interface DashboardProps {
  onNavigateToModule: () => void;
  onNavigateToQuiz: () => void;
  courseProgress: number;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigateToModule, onNavigateToQuiz, courseProgress }) => {
  return (
    <div className="animate-fade-in-up">
      <div className="text-center mb-12">
        <WrenchIcon className="mx-auto h-16 w-16 text-mec-orange" />
        <h1 className="text-4xl font-bold text-mec-carbon dark:text-white mt-4">Diagnóstico y Afinamiento Electrónico del Motor</h1>
        <p className="text-lg text-mec-gray dark:text-gray-300 mt-2">Bienvenido al centro de aprendizaje sobre diagnóstico y afinamiento electrónico.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <DashboardCard
          icon={<ToolboxIcon className="h-12 w-12 text-mec-blue" />}
          title="Módulo de Aprendizaje"
          description="Explora el sistema de alimentación de combustible con diagramas, componentes y casos de estudio."
          buttonText="Iniciar Módulo"
          onClick={onNavigateToModule}
        />
        <DashboardCard
          icon={<ChartBarIcon className="h-12 w-12 text-mec-blue" />}
          title="Quiz Final de Evaluación"
          description="Pon a prueba tus conocimientos con un examen de 20 preguntas y obtén tu calificación."
          buttonText="Iniciar Quiz"
          onClick={onNavigateToQuiz}
        />
      </div>
       <div className="mt-12 p-6 bg-mec-blue/10 dark:bg-mec-blue/20 rounded-lg max-w-4xl mx-auto">
        <h3 className="text-xl font-semibold text-mec-carbon dark:text-white mb-2">Progreso del Curso</h3>
        <div className="w-full bg-mec-gray/30 rounded-full h-4 dark:bg-gray-700">
          <div className="bg-mec-green h-4 rounded-full transition-all duration-500" style={{ width: `${courseProgress}%` }}></div>
        </div>
        <p className="text-sm text-mec-gray dark:text-gray-400 mt-2">{courseProgress}% completado</p>
      </div>
    </div>
  );
};

interface DashboardCardProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    buttonText: string;
    onClick: () => void;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ icon, title, description, buttonText, onClick }) => (
    <Card className="flex flex-col text-center items-center transition-transform transform hover:-translate-y-2">
        <div className="mb-4">{icon}</div>
        <h2 className="text-2xl font-bold text-mec-carbon dark:text-white mb-2">{title}</h2>
        <p className="text-mec-gray dark:text-gray-300 flex-grow mb-6">{description}</p>
        <button onClick={onClick} className="w-full bg-mec-orange text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition-colors">
            {buttonText}
        </button>
    </Card>
);


export default Dashboard;
