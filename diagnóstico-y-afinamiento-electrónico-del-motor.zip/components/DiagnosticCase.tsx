import React, { useState } from 'react';
import { DiagnosticCaseData } from '../types';
import Card from './shared/Card';
import { ArrowLeftIcon, WrenchIcon, CheckCircleIcon, XCircleIcon } from './Icons';

interface DiagnosticCaseProps {
  caseData: DiagnosticCaseData;
  onBack: () => void;
}

const DiagnosticCase: React.FC<DiagnosticCaseProps> = ({ caseData, onBack }) => {
  const [revealedTests, setRevealedTests] = useState<Set<string>>(new Set());
  const [selectedDiagnosis, setSelectedDiagnosis] = useState<number | null>(null);
  const [showConclusion, setShowConclusion] = useState(false);

  const handleRevealTest = (testName: string) => {
    setRevealedTests(prev => new Set(prev).add(testName));
  };

  const handleSelectDiagnosis = (index: number) => {
    if (showConclusion) return;
    setSelectedDiagnosis(index);
    setShowConclusion(true);
  };

  const isDiagnosisCorrect = selectedDiagnosis === caseData.correctDiagnosisIndex;

  return (
    <div className="animate-fade-in-up">
      <button onClick={onBack} className="flex items-center mb-4 text-mec-blue hover:underline">
        <ArrowLeftIcon className="h-5 w-5 mr-1" />
        Volver a la selección de casos
      </button>

      <Card>
        <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange mb-4">{caseData.title}</h3>
        
        {/* Step 1: Symptom */}
        <div className="mb-6">
          <h4 className="font-bold text-lg text-mec-carbon dark:text-white mb-2">1. Síntoma Reportado</h4>
          <p className="text-mec-gray dark:text-gray-300">{caseData.symptom}</p>
          {caseData.image && (
            <div className="mt-4 flex justify-center">
              <img src={caseData.image} alt={caseData.title} className="rounded-lg shadow-md max-w-sm" />
            </div>
          )}
        </div>

        {/* Step 2: Tests */}
        <div className="mb-6">
          <h4 className="font-bold text-lg text-mec-carbon dark:text-white mb-2">2. Realizar Pruebas</h4>
          <div className="space-y-3">
            {caseData.tests.map(test => (
              <div key={test.name}>
                <button
                  onClick={() => handleRevealTest(test.name)}
                  disabled={revealedTests.has(test.name)}
                  className="w-full text-left p-3 bg-white dark:bg-mec-gray/10 border border-mec-blue/20 rounded-md flex items-center justify-between transition-colors hover:bg-mec-blue/5 disabled:bg-mec-light-gray/50 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center">
                    <WrenchIcon className="h-5 w-5 text-mec-orange mr-3" />
                    <span className="font-semibold">{test.name}</span>
                  </div>
                  <span className="text-sm text-mec-gray dark:text-gray-400">
                    {revealedTests.has(test.name) ? 'Realizado' : 'Realizar prueba'}
                  </span>
                </button>
                {revealedTests.has(test.name) && (
                  <div className="p-3 mt-1 bg-mec-blue/5 dark:bg-mec-blue/10 rounded-md animate-fade-in">
                    <p><strong>Herramienta:</strong> {test.tool}</p>
                    <p><strong>Resultado:</strong> <span className="font-bold text-mec-yellow">{test.result}</span></p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        {/* Step 3: Diagnosis */}
        {revealedTests.size > 0 && (
          <div className="mb-6 animate-fade-in">
            <h4 className="font-bold text-lg text-mec-carbon dark:text-white mb-2">3. Diagnosticar la Causa</h4>
            <div className="space-y-3">
                {caseData.diagnoses.map((diagnosis, index) => {
                    let buttonClass = 'border-mec-gray/20 bg-white dark:bg-mec-gray/10 hover:bg-mec-orange/5 dark:hover:bg-mec-orange/10';
                    let icon = null;
                    if(showConclusion) {
                        if (index === caseData.correctDiagnosisIndex) {
                            buttonClass = 'border-mec-green bg-mec-green/10 ring-2 ring-mec-green';
                            icon = <CheckCircleIcon className="h-6 w-6 text-mec-green" />;
                        } else if (index === selectedDiagnosis) {
                            buttonClass = 'border-mec-red bg-mec-red/10 ring-2 ring-mec-red';
                            icon = <XCircleIcon className="h-6 w-6 text-mec-red" />;
                        }
                    }
                    return (
                        <button
                          key={index}
                          onClick={() => handleSelectDiagnosis(index)}
                          disabled={showConclusion}
                          className={`w-full text-left p-4 border rounded-lg transition-all flex items-center justify-between ${buttonClass}`}
                        >
                          <span className="text-mec-carbon dark:text-gray-200">{diagnosis}</span>
                          {icon}
                        </button>
                    );
                })}
            </div>
          </div>
        )}

        {/* Step 4: Conclusion */}
        {showConclusion && (
            <div className="animate-fade-in mt-6 pt-4 border-t border-mec-blue/20">
                <h4 className="font-bold text-lg text-mec-carbon dark:text-white mb-2">4. Conclusión y Solución</h4>
                <div className={`p-4 rounded-lg ${isDiagnosisCorrect ? 'bg-mec-green/10' : 'bg-mec-red/10'}`}>
                    <p className="font-semibold mb-2">
                        {isDiagnosisCorrect 
                            ? "¡Diagnóstico Correcto!"
                            : "Diagnóstico Incorrecto. La respuesta correcta era la opción #" + (caseData.correctDiagnosisIndex + 1)
                        }
                    </p>
                    <p className="text-mec-gray dark:text-gray-300 mb-2"><strong>Análisis:</strong> {caseData.conclusion}</p>
                    <p className="text-mec-gray dark:text-gray-300"><strong>Solución Recomendada:</strong> {caseData.solution}</p>
                </div>
            </div>
        )}
      </Card>
    </div>
  );
};

export default DiagnosticCase;
