

import React, { useState } from 'react';
import Card from './shared/Card';
import { ArrowLeftIcon, ClipboardCheckIcon, WrenchIcon } from './Icons';
import { ModuleTab, DiagnosticCaseData } from '../types';
import { MINI_QUIZ_QUESTIONS } from '../constants';
import MiniQuiz from './MiniQuiz';
import DiagnosticCase from './DiagnosticCase';


const tabs: ModuleTab[] = ['Introducción', 'Componentes', 'Tipos', 'Pruebas', 'Diagnóstico', 'Consejos'];

const DIAGNOSTIC_CASES: DiagnosticCaseData[] = [
  {
    id: 1,
    title: "Caso 1: Pérdida de Potencia",
    symptom: "El vehículo pierde potencia al acelerar y en subidas. El ralentí es inestable y a veces el motor se apaga.",
    image: 'https://i.postimg.cc/W3RFrsB3/perdida-potencia.jpg',
    tests: [
        { name: "Medir Presión de Combustible", tool: "Manómetro", result: "25 PSI, y cae a 15 PSI al acelerar. (Especificación: 40-45 PSI constantes)." },
        { name: "Medir Caudal de Combustible", tool: "Recipiente graduado", result: "0.3 L/min. (Especificación: > 0.8 L/min)." },
        { name: "Medir Amperaje de la Bomba", tool: "Pinza amperimétrica", result: "7.5 A. (Especificación: 4-6 A). El amperaje alto sugiere que la bomba está trabajando forzada." },
    ],
    diagnoses: ["Regulador de presión defectuoso", "Bomba de combustible débil o filtro principal obstruido", "Fuga en un inyector"],
    correctDiagnosisIndex: 1,
    conclusion: "El bajo caudal y la caída de presión al acelerar, junto con un amperaje alto, apuntan a una restricción severa en el sistema. El filtro de combustible principal está muy obstruido, lo que fuerza a la bomba a trabajar en exceso.",
    solution: "Reemplazar el filtro de combustible. Después, volver a medir la presión y el caudal para confirmar que se han normalizado. Si el problema persiste, la bomba podría haber sufrido un desgaste prematuro y necesitaría ser reemplazada."
  },
  {
    id: 2,
    title: "Caso 2: Humo Negro y Olor a Gasolina",
    symptom: "Sale humo negro por el escape, hay un fuerte olor a gasolina y el consumo de combustible es excesivo. El escáner muestra el código de falla P0172 (Mezcla Rica).",
    image: 'https://i.postimg.cc/PqjBJJ9T/humo-negro.jpg',
    tests: [
        { name: "Medir Presión de Combustible", tool: "Manómetro", result: "70 PSI. (Especificación: 40-45 PSI)." },
        { name: "Verificar Línea de Retorno", tool: "Inspección visual", result: "No hay flujo de combustible de retorno al tanque (en sistemas que aplique)." },
        { name: "Prueba de Presión Residual", tool: "Manómetro", result: "La presión se mantiene alta (>65 PSI) indefinidamente después de apagar el motor." },
    ],
    diagnoses: ["Bomba de combustible con sobrepresión", "Inyectores goteando", "Regulador de presión atascado cerrado o línea de retorno obstruida"],
    correctDiagnosisIndex: 2,
    conclusion: "Una presión excesivamente alta y constante indica que el sistema no puede liberar el exceso de presión. Esto causa que los inyectores entreguen mucho más combustible del necesario.",
    solution: "Reemplazar el regulador de presión de combustible. En sistemas sin retorno, el regulador forma parte del módulo de la bomba en el tanque."
  },
  {
    id: 3,
    title: "Caso 3: El Auto No Arranca",
    symptom: "El motor de arranque gira (da marcha) pero el motor no enciende. No se escucha el zumbido característico de la bomba de combustible al girar la llave a la posición 'ON'.",
    image: 'https://i.postimg.cc/tJnB8v4K/no-arranca.jpg',
    tests: [
        { name: "Verificar Fusible de la Bomba", tool: "Multímetro", result: "El fusible de 15A tiene continuidad (está en buen estado)." },
        { name: "Medir Voltaje en Conector de Bomba", tool: "Multímetro", result: "0V al dar marcha. (Especificación: ~12V)." },
        { name: "Puentear Relé de la Bomba", tool: "Cable de puente", result: "Al puentear los terminales 30 y 87 en el zócalo del relé, la bomba se activa y el motor arranca. El voltaje en la bomba es de 12.5V." },
    ],
    diagnoses: ["Bomba de combustible quemada (circuito abierto)", "ECU no envía señal de activación", "Relé de la bomba de combustible defectuoso o su circuito de control"],
    correctDiagnosisIndex: 2,
    conclusion: "La bomba funciona cuando se le suministra energía directamente, lo que la descarta como la causa del problema. La falla está en el circuito de control que la activa. Dado que el fusible está bien, el relé es el sospechoso principal.",
    solution: "Reemplazar el relé de la bomba de combustible. Es una reparación rápida y económica."
  },
  {
    id: 4,
    title: "Caso 4: Arranque Difícil en Caliente",
    symptom: "El motor arranca perfectamente en frío, pero si se apaga y se intenta volver a arrancar a los pocos minutos, el arranque es largo y dificultoso. A veces huele a gasolina.",
    image: 'https://i.postimg.cc/L5Y8x2dC/arranque-dificil.jpg',
    tests: [
        { name: "Medir Presión de Combustible (en marcha)", tool: "Manómetro", result: "42 PSI (dentro de especificación)." },
        { name: "Prueba de Presión Residual", tool: "Manómetro", result: "La presión cae de 42 PSI a 10 PSI en menos de 5 minutos después de apagar el motor. (Especificación: Debe mantenerse sobre 30 PSI)." },
        { name: "Inspección Visual de Inyectores", tool: "Banco de pruebas/visual", result: "Después de desmontar el riel y presurizar el sistema, se observa que el inyector del cilindro 3 gotea combustible." },
    ],
    diagnoses: ["Válvula de retención de la bomba defectuosa", "Fuga en la línea de combustible", "Uno o más inyectores están goteando"],
    correctDiagnosisIndex: 2,
    conclusion: "La presión de funcionamiento es correcta, pero la rápida caída de presión residual indica una fuga interna. El goteo de un inyector 'ahoga' el cilindro con combustible, dificultando el re-arranque en caliente.",
    solution: "Reemplazar el inyector defectuoso y sus sellos (O-rings). Se recomienda limpiar y probar los demás inyectores mientras el riel está desmontado."
  }
];

interface ModuleViewProps {
  onBack: () => void;
  markQuizAsCompleted: (quizKey: string) => void;
}

const ModuleView: React.FC<ModuleViewProps> = ({ onBack, markQuizAsCompleted }) => {
  const [activeTab, setActiveTab] = useState<ModuleTab>('Introducción');
  const [activeMiniQuiz, setActiveMiniQuiz] = useState<ModuleTab | null>(null);
  const [activeCaseIndex, setActiveCaseIndex] = useState<number | null>(null);

  const handleMiniQuizComplete = () => {
    if(activeMiniQuiz) {
        markQuizAsCompleted(activeMiniQuiz);
    }
    setActiveMiniQuiz(null);
  };

  const renderContent = () => {
    if (activeCaseIndex !== null) {
      return <DiagnosticCase caseData={DIAGNOSTIC_CASES[activeCaseIndex]} onBack={() => setActiveCaseIndex(null)} />;
    }

    switch (activeTab) {
      case 'Introducción':
        return (
          <div className="space-y-4 animate-fade-in text-mec-gray dark:text-gray-300">
            <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange">Diagnóstico Electrónico del Sistema de Alimentación de Combustible en Motores de Inyección Electrónica</h3>
            
            <div className="my-6 flex justify-center">
              <a href='https://postimg.cc/vxwYmmbR' target='_blank' rel="noopener noreferrer">
                <img 
                  src='https://i.postimg.cc/mktt8cnr/componentes-funcionamiento-sistemas-combustible2.png' 
                  alt='Componentes, funcionamiento y sistemas de combustible'
                  className="rounded-lg shadow-lg max-w-full h-auto border-0"
                />
              </a>
            </div>

            <h4 className="font-semibold text-lg dark:text-white">Introducción</h4>
            <p>Bienvenidos al seminario de diagnóstico electrónico del sistema de alimentación de combustible para motores de inyección electrónica indirecta de 4 gasolina (MPI - Inyección Multipunto Indirecta). Este documento, diseñado para estudiantes de Mecánica Automotriz, proporciona una comprensión exhaustiva de los componentes, tipos de sistemas y procedimientos de diagnóstico aplicados a distintos motores, típicos en vehículos compactos y medianos.</p>
            <p>El sistema de alimentación de combustible es fundamental para garantizar una combustión eficiente, y su correcto funcionamiento equilibra rendimiento, economía y emisiones. Esta presentacion, esta basado en descripciones textuales y herramientas genéricas, detalla las partes del sistema, los tipos de configuraciones y las pruebas esenciales, enriquecidas con técnicas de diagnóstico, para identificar fallas como presión insuficiente o anomalías en la bomba de combustible.</p>
          </div>
        );
      case 'Componentes':
        return (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange">Sección 1: Partes del Sistema de Alimentación de Combustibles</h3>
            <p className="text-mec-gray dark:text-gray-300">El sistema de alimentación de combustible en un motor de inyección indirecta de 4 cilindros consta de componentes diseñados para suministrar gasolina de manera precisa a cada cilindro. A continuación, se describen sus partes principales:</p>
            
            <ComponentDetail title="1. Bomba de gasolina">
              <div className="my-4 flex justify-center">
                <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                  <img 
                    src='https://i.postimg.cc/yYgmnmLq/bomba-combustible.jpg' 
                    alt='Bomba de combustible'
                    className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                  />
                </a>
              </div>
              <p><strong>Función:</strong> Transporta combustible desde el tanque hacia el riel de inyectores, generando presión suficiente para quatro inyectores.</p>
              <p><strong>Ubicación:</strong> Dentro del tanque de combustible, como una bomba eléctrica sumergible.</p>
              <p><strong>Características:</strong> En motores de 4 cilindros, opera entre 2,5 y 4,5 bar, con un caudal adaptado a un desplazamiento típico de 1,6 a 2,5 litros. Produce un zumbido audible al activarse.</p>
            </ComponentDetail>

            <ComponentDetail title="2. Filtro de la Bomba de Gasolina (Prefiltro o Malla)">
              <div className="my-4 flex justify-center">
                <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                  <img 
                    src='https://i.postimg.cc/Y2GcNVBt/filtro-de-la-bomba-de-gasolina.webp' 
                    alt='Filtro de la bomba de gasolina'
                    className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                  />
                </a>
              </div>
              <p><strong>Función:</strong> Filtra partículas grandes (arena, sedimentos) antes de que el combustible ingrese a la bomba.</p>
              <p><strong>Ubicación:</strong> En la entrada de la bomba, dentro del tanque.</p>
              <p><strong>Importancia:</strong> Una obstrucción puede reducir el suministro a los cuatro cilindros, afectando el rendimiento.</p>
            </ComponentDetail>

            <ComponentDetail title="3. Regulador de Presión de Combustible">
              <div className="my-4 flex justify-center">
                <a href='https://postimg.cc/kDy9m67x' target='_blank' rel="noopener noreferrer">
                  <img 
                    src='https://i.postimg.cc/7PFLS0cQ/regulador-de-presion12.png' 
                    alt='Regulador de presión'
                    className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                  />
                </a>
              </div>
              <p><strong>Función:</strong> Asegurar que la presión en el riel de inyectores sea constante, ajustándola según las demandas del motor.</p>
              <p><strong>Ubicación:</strong> En el riel de combustible (sistemas con retorno) o cerca del tanque (sistemas sin retorno).</p>
              <p><strong>Operación:</strong> En motores de 4 cilindros, regulada periódicamente entre 2,5 y 3,5 bar en sistemas con retorno.</p>
            </ComponentDetail>

            <ComponentDetail title="4. Filtro del Sistema de Alimentación de Combustibles">
                <div className="my-4 flex justify-center">
                    <a href='https://postimg.cc/CRgjfQ3y' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/cLKTPqTJ/filtro-de-combustible.png' 
                            alt='filtro-de-combustible'
                            className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Función:</strong> Eliminar impurezas finas que podrían dañar los inyectores, como polvo o residuos metálicos.</p>
                <p><strong>Ubicación:</strong> En la línea de presión, entre la bomba y el riel de inyectores.</p>
                <p><strong>Mantenimiento:</strong> En motores de 4 cilindros, se recomienda cambiarlo cada 40.000 km a 60.000 km debido al volumen moderado de combustible procesado.</p>
            </ComponentDetail>

            <ComponentDetail title="5. Cañerías (Líneas de Combustibles)">
                <div className="my-4 flex justify-center">
                    <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/MpRVyzd1/ca-erias.jpg' 
                            alt='ca-erias'
                            className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Función:</strong> Conduce el combustible desde el tanque hasta los inyectores, soportando presión y vibraciones.</p>
                <p><strong>Material:</strong> Tuberías de acero o plástico reforzado, dimensionadas para caudales de motores pequeños.</p>
                <p><strong>Consideraciones:</strong> En un motor de 4 cilindros, las líneas son cortas, pero deben inspeccionarse por fugas.</p>
            </ComponentDetail>

            <ComponentDetail title="6. Inyectores de gasolina">
                <div className="my-4 flex justify-center">
                    <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/YCk1kh6j/inyectores.webp' 
                            alt='inyectores'
                            className="rounded-lg shadow-lg max-w-xs h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Función:</strong> Pulverizan combustible en el colector de admisión, uno por cilindro (cuatro en total).</p>
                <p><strong>Ubicación:</strong> Montados en el riel de combustible, cerca de las válvulas de admisión.</p>
                <p><strong>Control:</strong> Gestionados por la ECU, con tiempos de inyección de 2-8 ms en un motor de 4 cilindros a ralentí.</p>
            </ComponentDetail>

          </div>
        );
      case 'Tipos':
        return (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange">Sección 2: Tipos de Sistemas de Alimentación de Combustibles</h3>
             <ComponentDetail title="1. Sistema de Alimentación con Retorno Largo">
                <div className="my-4 flex justify-center">
                    <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/4dzh9PPZ/con-retorno-largo.gif' 
                            alt='con-retorno-largo'
                            className="rounded-lg shadow-lg max-w-md h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Descripción:</strong> El combustible fluye desde el tanque al riel de inyectores y retorna al tanque por una línea larga tras pasar por el regulador.</p>
                <p><strong>Regulador:</strong> Situado en el riel, ajusta la presión a 2,5-3,2 bar (35 a 42PSI) y devuelve el exceso al tanque.</p>
                <p><strong>Uso:</strong> en vehículos con motor con inyección indirecta de los años 80 y 90.</p>
                <p><strong>Característica:</strong> Mantiene el combustible fresco, pero aumenta la complejidad.</p>
             </ComponentDetail>
             <ComponentDetail title="2. Sistema de Alimentación con Retorno Corto">
                <div className="my-4 flex justify-center">
                    <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/L8nD1d1p/con-rtorno-corto.webp' 
                            alt='con-rtorno-corto'
                            className="rounded-lg shadow-lg max-w-md h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Descripción:</strong> El regulador está cerca de la bomba o en el tanque, reduciendo la longitud de la línea de retorno (Volkswagen lleva un filtro de combustible externo que tiene integrado un regulador de presión).</p>
                <p><strong>Ventaja:</strong> Simplifica el diseño y es común en motores de 4 cilindros de transición (1990-2000).</p>
                <p><strong>Presión:</strong> Similar al retorno largo, ajustada a 3 bar (42 PSI) en promedio.</p>
             </ComponentDetail>
             <ComponentDetail title="3. Sistema de Alimentación sin Retorno">
                 <div className="my-4 flex justify-center">
                    <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/Qd8t4sq2/sinretorno-1.jpg' 
                            alt='Sistema de alimentación sin retorno'
                            className="rounded-lg shadow-lg max-w-md h-auto border-0"
                        />
                    </a>
                </div>
                <p><strong>Descripción:</strong> No usa línea de retorno; la presión se regula en el módulo de la bomba. La bomba de combustible, activada por el relé que a su vez es activada por la computadora, envía el combustible al regulador, donde el exceso retorna al tanque.</p>
                <p><strong>Regulación:</strong> Se caracteriza por tener el regulador de presión dentro del tanque de combustible. La presión regulada se mantiene constante y es superior a los 50 psi.</p>
                <p><strong>Uso:</strong> Predominante en motores de inyeccion indirecta modernos (posteriores a 2005).</p>
                <p><strong>Beneficio:</strong> Reducir el calentamiento del combustible en aplicaciones compactas.</p>
             </ComponentDetail>
              <ComponentDetail title="4. Sistema de Alimentación con Regulación de Presión Electrónica">
                 <div className="my-4 flex justify-center">
                    <a href='https://postimg.cc/tYJnLHFN' target='_blank' rel="noopener noreferrer">
                        <img 
                            src='https://i.postimg.cc/sD9PGjXq/gdi-image.jpg' 
                            alt='gdi-image'
                            className="rounded-lg shadow-lg max-w-md h-auto border-0"
                        />
                    </a>
                </div>
                 <p><strong>Descripción:</strong> La presión se controla en tiempo real mediante sensores (de alta y baja presión) y una bomba de velocidad variable a través de un módulo y la ECM.</p>
                 <p><strong>Regulación:</strong> La bomba ajusta su velocidad a revoluciones cambiantes constantemente y de esa forma se logra mantener la presión de 4,0-5,0 bar (58 a 73 PSI).</p>
                 <p><strong>Uso:</strong> En motores de inyección directa, motor Otto.</p>
                 <p><strong>Ventaja:</strong> Optimiza el consumo energético y la respuesta del motor.</p>
              </ComponentDetail>
             <ComparativeTable />
          </div>
        );
      case 'Pruebas':
        return (
            <div className="space-y-6 animate-fade-in">
                <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange">Sección 3: Pruebas de Diagnóstico</h3>
                <p className="text-mec-gray dark:text-gray-300">El diagnóstico en un motor de 4 cilindros requiere medir presión, caudal y parámetros eléctricos de la bomba, con técnicas prácticas incorporadas para verificar su funcionamiento eléctrico y mecánico.</p>
                <TestDetail title="1. Pruebas de presión">
                    <div className="my-4 flex justify-center">
                        <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                            <img 
                                src='https://i.postimg.cc/qMwhdQj6/medir-presion.png' 
                                alt='medir-presion'
                                className="rounded-lg shadow-lg max-w-md h-auto border-0"
                            />
                        </a>
                    </div>
                    <p><strong>Herramienta:</strong> Manómetro de combustible (rango 0-10 bar).</p>
                    <p><strong>Procedimiento:</strong> 1. Localizar el puerto de prueba. 2. Encender el motor o activar la bomba. 3. Medir la presión en ralentí y a 2500 RPM.</p>
                    <p><strong>Valores típicos:</strong> Sistema con retorno: 2,5-3,0 bar. Sistema sin retorno: 3,8-4,2 bar.</p>
                    <p><strong>Diagnóstico:</strong> Presión baja (&lt;2,5 bar): Bomba desgastada, filtro obstruido o fuga. Presión alta (&gt;4,5 bar): Regulador atascado o línea de retorno bloqueada.</p>
                </TestDetail>
                 <TestDetail title="2. Prueba de Presión Residual">
                    <div className="my-4 flex justify-center">
                        <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                            <img 
                                src='https://i.postimg.cc/76cv7vHJ/presion-residual.jpg' 
                                alt='presion-residual'
                                className="rounded-lg shadow-lg max-w-md h-auto border-0"
                            />
                        </a>
                    </div>
                    <p><strong>Objetivo:</strong> Verificar que el sistema mantiene la presión de combustible después de apagar el motor, lo que ayuda a un arranque rápido.</p>
                    <p><strong>Especificaciones Típicas:</strong> La presión debe mantenerse por encima 30 psi a 40 psi después de apagar el motor.</p>
                    <p><strong>Tolerancia:</strong> Una caída rápida de presión indica fugas en el sistema, un regulador de presión defectuoso o inyectores que gotean.</p>
                </TestDetail>
                 <TestDetail title="3. Prueba de caudal">
                    <div className="my-4 flex justify-center">
                        <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                            <img 
                                src='https://i.postimg.cc/gkHSb9Cy/caudal1.png' 
                                alt='caudal1'
                                className="rounded-lg shadow-lg max-w-md h-auto border-0"
                            />
                        </a>
                    </div>
                    <p><strong>Herramienta:</strong> Recipiente graduado y manguera de desvío.</p>
                    <p><strong>Procedimiento:</strong> 1. Desconectar la línea de presión. 2. Activar la bomba por 30 segundos. 3. Medir el volumen recolectado.</p>
                    <p><strong>Valor Típico:</strong> 0,5-0,8 litros (para motores de 1,6-2,0L).</p>
                    <p><strong>Diagnóstico:</strong> Caudal bajo (&lt;0,5 L/min): Bomba débil o prefiltro tapado.</p>
                </TestDetail>
                <TestDetail title="4. Medición de Consumo de Amperaje de la Bomba">
                    <p><strong>Herramienta:</strong> Multímetro con pinza amperimétrica.</p>
                    <p><strong>Procedimiento:</strong> 1. Acceder al cable positivo de la bomba. 2. Activar la bomba y medir el amperaje.</p>
                    <p><strong>Valor Típico:</strong> 4-6 amperios.</p>
                    <p><strong>Diagnóstico:</strong> Amperaje alto (&gt;6 A): Bomba forzada o cortocircuito. Amperaje bajo (&lt;3 A): Circuito incompleto o bomba dañada.</p>
                    <p><strong>Nota:</strong> Se debe mencionar que la bomba de gasolina deberá consumir de 0.8 a 1.0 Amp. por cada 10 psi de presión que genera.</p>
                </TestDetail>
                <TestDetail title="5. Medición de Resistencia de la Bomba">
                    <div className="my-4 flex justify-center">
                        <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                            <img 
                                src='https://i.postimg.cc/kg5cr2F9/medicion-de-resistencia.png' 
                                alt='medicion-de-resistencia'
                                className="rounded-lg shadow-lg max-w-md h-auto border-0"
                            />
                        </a>
                    </div>
                    <p><strong>Herramienta:</strong> Multímetro en modo ohmios.</p>
                    <p><strong>Procedimiento:</strong> 1. Desconectar el conector eléctrico. 2. Medir la resistencia entre los terminales.</p>
                    <p><strong>Valor Típico:</strong> 0,8-1,5 ohmios.</p>
                    <p><strong>Diagnóstico:</strong> Resistencia infinita: Bomba abierta (quemada). Resistencia baja (&lt;0,5 Ω): Cortocircuito interno.</p>
                </TestDetail>
                <TestDetail title="6. Medición de Voltaje y Verificación Operativa">
                    <div className="my-4 flex justify-center">
                        <a href='https://postimages.org/' target='_blank' rel="noopener noreferrer">
                            <img 
                                src='https://i.postimg.cc/jSJDJKRP/medicion-de-voltaje.jpg' 
                                alt='medicion-de-voltaje'
                                className="rounded-lg shadow-lg max-w-md h-auto border-0"
                            />
                        </a>
                    </div>
                    <p><strong>Herramientas:</strong> Multímetro, lámpara de prueba, cables.</p>
                    <p><strong>Procedimiento:</strong> Verificar zumbido, energía en fusible/relé, voltaje en conector durante arranque, y prueba directa con 12V.</p>
                    <p><strong>Valor Típico:</strong> 12-13,5 V (con motor en marcha).</p>
                    <p><strong>Diagnóstico:</strong> Sin zumbido: Bomba no recibe energía o está dañada. Lámpara no enciende: Fusible/relé defectuoso. Voltaje bajo (&lt;11 V): Caída en cableado/relé.</p>
                </TestDetail>
            </div>
        );
      case 'Diagnóstico':
        return (
            <div className="space-y-6 animate-fade-in">
                <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange">Sección 5: Casos de Diagnóstico Interactivo</h3>
                <p className="text-mec-gray dark:text-gray-300">Aplica tus conocimientos para resolver problemas del mundo real. Selecciona un caso para comenzar el diagnóstico.</p>
                <div className="grid md:grid-cols-2 gap-6">
                    {DIAGNOSTIC_CASES.map((caseItem, index) => (
                        <button
                            key={caseItem.id}
                            onClick={() => setActiveCaseIndex(index)}
                            className="p-6 bg-white dark:bg-mec-gray/20 border border-mec-blue/20 rounded-lg shadow-md text-left hover:border-mec-orange hover:ring-2 hover:ring-mec-orange transition-all transform hover:-translate-y-1"
                        >
                            <div className="flex items-center mb-2">
                                <ClipboardCheckIcon className="h-6 w-6 text-mec-blue mr-3" />
                                <h4 className="font-bold text-lg text-mec-carbon dark:text-white">{caseItem.title}</h4>
                            </div>
                            <p className="text-sm text-mec-gray dark:text-gray-300 line-clamp-2">{caseItem.symptom}</p>
                        </button>
                    ))}
                </div>
            </div>
        );
      case 'Consejos':
        return (
          <div className="space-y-6 animate-fade-in text-mec-gray dark:text-gray-300">
            <div>
                <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange mb-3">Sección 4: Consejos Prácticos para Estudiantes</h3>
                <ul className="list-disc list-inside space-y-2">
                    <li><strong>Seguridad:</strong> Despresurizar el sistema quitando el fusible de la bomba y arrancando el motor hasta que se detenga.</li>
                    <li><strong>Interpretación:</strong> Fallas en la bomba se manifiestan con arranques difíciles, apagones o ralentí inestables.</li>
                    <li><strong>Herramientas:</strong> Usar un escáner genérico para leer códigos OBD-II.</li>
                    <li><strong>Práctica:</strong> Realizar pruebas en un vehículo de laboratorio y comparar resultados con especificaciones.</li>
                    <li><strong>Diagnóstico inicial:</strong> Siempre escuchar el zumbido de la bomba y verificar fusibles/relés antes de desmontar.</li>
                </ul>
            </div>
            <div>
                <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange mb-3">Recomendaciones para Garantizar un Buen Trabajo</h3>
                 <ul className="list-disc list-inside space-y-2">
                    <li><strong>Uso de Combustible de Calidad:</strong> Utilizar gasolina de octanaje adecuado para proteger la bomba y los inyectores.</li>
                    <li><strong>Mantenimiento Preventivo de Filtros:</strong> Cambiar el filtro de combustible cada 40.000-60.000 km.</li>
                    <li><strong>Inspección Regular de las Cañerías:</strong> Verificar cada 20.000 km para detectar fugas, corrosión o desgaste.</li>
                    <li><strong>Limpieza de Inyectores:</strong> Limpiar cada 50.000 km con aditivos o equipos de ultrasonido.</li>
                    <li><strong>Monitoreo de la Bomba de Gasolina:</strong> Medir amperaje y voltaje cada 30.000 km o ante síntomas.</li>
                    <li><strong>Revisión del Regulador de Presión:</strong> Comprobar su funcionamiento en cada servicio mayor.</li>
                    <li><strong>Evitar Operar con Tanque Bajo:</strong> Mantener al menos un cuarto de combustible para evitar sobrecalentamiento de la bomba.</li>
                </ul>
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  
  const showMiniQuizButton = ['Componentes', 'Tipos', 'Pruebas'].includes(activeTab);

  if (activeMiniQuiz) {
      const questions = MINI_QUIZ_QUESTIONS[activeMiniQuiz];
      if (questions) {
          return (
              <Card className="w-full max-w-3xl mx-auto">
                  <MiniQuiz 
                      questions={questions} 
                      onComplete={handleMiniQuizComplete} 
                      quizTitle={activeMiniQuiz}
                  />
              </Card>
          );
      }
  }


  return (
    <Card className="w-full max-w-5xl mx-auto animate-fade-in-up">
        <div className="flex items-center mb-6">
            <button onClick={onBack} className="p-2 rounded-full hover:bg-mec-light-gray dark:hover:bg-mec-gray/50 transition-colors mr-4">
                <ArrowLeftIcon className="h-6 w-6 text-mec-carbon dark:text-white" />
            </button>
            <h2 className="text-3xl font-bold text-mec-carbon dark:text-white">Módulo: Sistema de Alimentación</h2>
        </div>
      
      <div className="mb-4">
        <nav className="flex space-x-2 overflow-x-auto" aria-label="Tabs">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); setActiveCaseIndex(null); }}
              className={`py-2 px-4 rounded-t-lg font-semibold text-sm transition-colors focus:outline-none
                ${activeTab === tab
                  ? 'bg-mec-blue text-white dark:bg-mec-orange dark:text-mec-carbon'
                  : 'text-mec-gray hover:bg-mec-blue/10 dark:text-gray-400 dark:hover:bg-mec-gray/40'
                }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>
      <div className="p-4 bg-mec-blue/5 dark:bg-mec-carbon/50 rounded-lg min-h-[400px]">
        {renderContent()}
        {showMiniQuizButton && activeCaseIndex === null && (
            <div className="mt-8 text-center">
                <button 
                    onClick={() => setActiveMiniQuiz(activeTab as ModuleTab)}
                    className="bg-mec-orange text-white font-bold py-3 px-8 rounded-lg hover:bg-opacity-90 transition-all transform hover:scale-105"
                >
                    Iniciar Repaso Rápido
                </button>
            </div>
        )}
      </div>
    </Card>
  );
};

const ComponentDetail: React.FC<{title: string, children: React.ReactNode}> = ({ title, children }) => (
    <div className="p-4 border-l-4 border-mec-blue bg-white dark:bg-mec-gray/10 rounded-r-lg">
        <h4 className="font-bold text-lg text-mec-carbon dark:text-white mb-2">{title}</h4>
        <div className="space-y-1 text-mec-gray dark:text-gray-300">
            {children}
        </div>
    </div>
);

const TestDetail = ComponentDetail;

const ComparativeTable = () => (
    <div className="overflow-x-auto">
        <h4 className="text-xl font-bold text-mec-blue dark:text-mec-orange my-4">Tabla Comparativa de Sistemas</h4>
        <table className="w-full text-sm text-left text-mec-gray dark:text-gray-300 border-collapse">
            <thead className="bg-mec-blue/10 dark:bg-mec-blue/20 text-mec-carbon dark:text-white">
                <tr>
                    <th className="p-2 border border-mec-blue/20">Característica</th>
                    <th className="p-2 border border-mec-blue/20">Retorno Largo</th>
                    <th className="p-2 border border-mec-blue/20">Retorno Corto</th>
                    <th className="p-2 border border-mec-blue/20">Sin Retorno</th>
                    <th className="p-2 border border-mec-blue/20">Control PWM</th>
                </tr>
            </thead>
            <tbody>
                <tr className="bg-white dark:bg-mec-gray/10">
                    <td className="p-2 border border-mec-blue/20 font-semibold">Línea de Retorno</td>
                    <td className="p-2 border border-mec-blue/20">Sí</td>
                    <td className="p-2 border border-mec-blue/20">Sí</td>
                    <td className="p-2 border border-mec-blue/20">No</td>
                    <td className="p-2 border border-mec-blue/20">No</td>
                </tr>
                 <tr className="bg-mec-light-gray/50 dark:bg-mec-gray/20">
                    <td className="p-2 border border-mec-blue/20 font-semibold">Regulador de Presión</td>
                    <td className="p-2 border border-mec-blue/20">Riel de Inyección</td>
                    <td className="p-2 border border-mec-blue/20">Posiblemente en el filtro</td>
                    <td className="p-2 border border-mec-blue/20">En el Tanque</td>
                    <td className="p-2 border border-mec-blue/20">Controlado por Módulo</td>
                </tr>
            </tbody>
        </table>
    </div>
);

export default ModuleView;
