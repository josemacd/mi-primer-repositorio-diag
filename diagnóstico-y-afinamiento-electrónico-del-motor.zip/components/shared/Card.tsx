
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', id }) => {
  return (
    <div id={id} className={`bg-white dark:bg-mec-gray/20 border border-mec-blue/20 rounded-lg shadow-md p-6 ${className}`}>
      {children}
    </div>
  );
};

export default Card;
