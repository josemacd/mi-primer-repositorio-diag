
import React, { useState, useCallback } from 'react';
import { Question, Student, Answers, QuizResultDetails, QuizCategory } from '../types';
import Card from './shared/Card';
import { ArrowLeftIcon, ShareIcon, CheckIcon, CheckCircleIcon, XCircleIcon } from './Icons';

interface QuizResultsProps {
  student: Student;
  questions: Question[];
  answers: Answers;
  timeTaken: number;
  onRestart: () => void;
}

const QuizResults: React.FC<QuizResultsProps> = ({ student, questions, answers, timeTaken, onRestart }) => {
  const [isCopied, setIsCopied] = useState(false);

  const results = React.useMemo<QuizResultDetails>(() => {
    let correct = 0;
    const categoryPerformance: { [key in QuizCategory]: { correct: number; total: number } } = {
      [QuizCategory.FUNCTIONING]: { correct: 0, total: 0 },
      [QuizCategory.SYSTEM_TYPES]: { correct: 0, total: 0 },
      [QuizCategory.COMPONENTS]: { correct: 0, total: 0 },
      [QuizCategory.TESTS]: { correct: 0, total: 0 },
      [QuizCategory.DIAGNOSIS]: { correct: 0, total: 0 },
    };

    questions.forEach((q, index) => {
      const category = q.category;
      if (categoryPerformance[category]) {
        categoryPerformance[category].total++;
        if (answers[index] === q.correctAnswer) {
          correct++;
          categoryPerformance[category].correct++;
        }
      }
    });

    return {
      correctAnswers: correct,
      totalQuestions: questions.length,
      score: Math.round((correct / questions.length) * 100),
      timeTaken: Math.floor(timeTaken / 60),
      categoryPerformance,
    };
  }, [questions, answers, timeTaken]);

  const isApproved = results.score >= 70;
  
  const handleShare = useCallback(() => {
    if (!student || !results || !questions || !answers) return;

    let reportText = `
📊 Reporte de Evaluación 📊
---------------------------------
Estudiante: ${student.fullName} ${student.lastName}
ID: ${student.idNumber}
Puntuación Final: ${results.score}/100
Estado: ${results.score >= 70 ? '✅ APROBADO' : '❌ REPROBADO'}
Respuestas correctas: ${results.correctAnswers}/${results.totalQuestions}
---------------------------------

🔍 Revisión Detallada de Preguntas 🔍
`;

    questions.forEach((q, index) => {
        const studentAnswerIndex = answers[index];
        const correctAnswerIndex = q.correctAnswer;
        const studentAnswerText = studentAnswerIndex !== undefined ? q.options[studentAnswerIndex] : "No respondida";
        const correctAnswerText = q.options[correctAnswerIndex];
        const isCorrect = studentAnswerIndex === correctAnswerIndex;

        reportText += `
\n---------------------------------\n
Pregunta ${index + 1}: ${q.question}
\n
Tu respuesta: "${studentAnswerText}" ${isCorrect ? '✅' : '✗'}
`;
        if (!isCorrect) {
            reportText += `\nRespuesta correcta: "${correctAnswerText}"`;
        }
    });

    navigator.clipboard.writeText(reportText.trim()).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }).catch(err => {
      console.error('Error al copiar al portapapeles:', err);
      alert('No se pudo copiar el texto.');
    });
  }, [student, results, questions, answers]);


  return (
    <div className="p-4 md:p-8 animate-fade-in-up">
      <div className="max-w-4xl mx-auto">
        <Card className="w-full" id="report-card">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-mec-carbon dark:text-white">📊 REPORTE DE EVALUACIÓN 📊</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-6 mb-6 text-sm text-mec-gray dark:text-gray-300">
            <div><strong>Estudiante:</strong> {student.fullName} ${student.lastName}</div>
            <div><strong>ID:</strong> {student.idNumber}</div>
            <div><strong>Fecha:</strong> {new Date().toLocaleString()}</div>
            <div><strong>Duración:</strong> {results.timeTaken} minutos de 30</div>
          </div>

          <div className={`p-6 rounded-lg text-center my-6 ${isApproved ? 'bg-mec-green/10' : 'bg-mec-red/10'}`}>
            <h3 className="text-2xl font-bold">🎯 PUNTUACIÓN FINAL: {results.score}/100</h3>
            <p className={`text-xl font-semibold ${isApproved ? 'text-mec-green' : 'text-mec-red'}`}>
              {isApproved ? `✅ APROBADO (${results.score}%)` : `❌ REPROBADO (${results.score}%)`}
            </p>
            <p className="text-mec-gray dark:text-gray-300">Respuestas correctas: {results.correctAnswers}/{results.totalQuestions}</p>
          </div>

          <div>
            <h4 className="text-xl font-bold text-mec-carbon dark:text-white mb-4">📈 Análisis por categorías:</h4>
            <div className="space-y-3">
              {Object.entries(results.categoryPerformance).filter(([,data]) => data.total > 0).map(([category, data]) => {
                const percentage = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;
                return (
                  <div key={category}>
                    <div className="flex justify-between mb-1 text-sm font-medium text-mec-gray dark:text-gray-300">
                      <span>{category}</span>
                      <span>{data.correct}/{data.total} ({percentage}%)</span>
                    </div>
                    <div className="w-full bg-mec-light-gray dark:bg-mec-gray rounded-full h-2.5">
                      <div className="bg-mec-blue h-2.5 rounded-full" style={{ width: `${percentage}%` }}></div>
                    </div>
                    {percentage < 75 && data.total > 0 && (
                      <p className="text-xs text-mec-yellow mt-1">Se recomienda repasar este módulo para reforzar conceptos.</p>
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-mec-blue/20">
            <h4 className="text-xl font-bold text-mec-carbon dark:text-white mb-4">🔍 Revisión de Preguntas:</h4>
            <div className="space-y-6">
              {questions.map((q, index) => {
                const studentAnswerIndex = answers[index];
                const correctAnswerIndex = q.correctAnswer;
                const isStudentAnswerUndefined = studentAnswerIndex === undefined;

                return (
                  <div key={index} className="p-4 bg-mec-light-gray/50 dark:bg-mec-carbon/50 rounded-lg text-sm">
                    <p className="font-semibold mb-3">
                      <span className="font-bold text-mec-blue">{index + 1}.</span> {q.question}
                    </p>
                    <div className="space-y-2">
                      {q.options.map((option, optionIndex) => {
                        const isCorrect = optionIndex === correctAnswerIndex;
                        const isStudentSelection = optionIndex === studentAnswerIndex;
                        
                        let optionClass = "border-transparent";
                        let icon = null;

                        if (isCorrect) {
                            optionClass = "bg-mec-green/20 border-mec-green/50 font-semibold";
                            icon = <CheckCircleIcon className="h-5 w-5 ml-auto text-mec-green" />;
                        }
                        
                        if (isStudentSelection && !isCorrect) {
                            optionClass = "bg-mec-red/20 border-mec-red/50 font-semibold";
                            icon = <XCircleIcon className="h-5 w-5 ml-auto text-mec-red" />;
                        }

                        return (
                          <div
                            key={optionIndex}
                            className={`flex items-center justify-between p-3 rounded-md border ${optionClass}`}
                          >
                            <span className="text-mec-gray dark:text-gray-300">
                              <span className="font-bold mr-2">{String.fromCharCode(65 + optionIndex)}.</span>
                              {option}
                            </span>
                            {icon}
                          </div>
                        );
                      })}
                       {isStudentAnswerUndefined && (
                            <p className="text-xs text-mec-yellow mt-2">No se respondió esta pregunta.</p>
                        )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
        
        <div className="mt-6 flex flex-wrap justify-center gap-4 no-print">
            <button onClick={onRestart} className="flex items-center bg-mec-blue text-white font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-colors">
                <ArrowLeftIcon className="h-5 w-5 mr-2" /> Volver al Inicio
            </button>
            <button
              onClick={handleShare}
              className={`flex items-center text-white font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-all ${isCopied ? 'bg-mec-green' : 'bg-mec-orange'}`}
              disabled={isCopied}
            >
              {isCopied ? (
                <>
                  <CheckIcon className="h-5 w-5 mr-2" />
                  ¡Copiado!
                </>
              ) : (
                <>
                  <ShareIcon className="h-5 w-5 mr-2" />
                  Compartir Resultados
                </>
              )}
            </button>
        </div>
      </div>
    </div>
  );
};

export default QuizResults;
