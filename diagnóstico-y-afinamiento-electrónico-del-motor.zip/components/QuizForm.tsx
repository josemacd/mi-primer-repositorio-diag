
import React, { useState, useMemo } from 'react';
import Card from './shared/Card';
import { UserIcon, IdCardIcon, GraduationCapIcon } from './Icons';
import { Student } from '../types';

interface QuizFormProps {
  onStartQuiz: (student: Student) => void;
}

const QuizForm: React.FC<QuizFormProps> = ({ onStartQuiz }) => {
  const [fullName, setFullName] = useState('');
  const [lastName, setLastName] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [errors, setErrors] = useState({ fullName: '', lastName: '', idNumber: '' });

  const validate = () => {
    const newErrors = { fullName: '', lastName: '', idNumber: '' };
    let isValid = true;
    if (fullName.trim().length < 3) {
      newErrors.fullName = 'Nombres deben tener al menos 3 caracteres.';
      isValid = false;
    }
    if (lastName.trim().length < 3) {
      newErrors.lastName = 'Apellidos deben tener al menos 3 caracteres.';
      isValid = false;
    }
    if (!/^\d{5,}$/.test(idNumber.trim())) {
      newErrors.idNumber = 'ID debe ser numérico y tener al menos 5 dígitos.';
      isValid = false;
    }
    setErrors(newErrors);
    return isValid;
  };

  const isFormValid = useMemo(() => {
    return fullName.trim().length >= 3 && lastName.trim().length >= 3 && /^\d{5,}$/.test(idNumber.trim());
  }, [fullName, lastName, idNumber]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onStartQuiz({
        fullName,
        lastName,
        idNumber,
        courseCode: 'AUTO-MEC-101',
      });
    }
  };

  return (
    <div className="flex justify-center items-center min-h-full p-4 animate-fade-in-up">
      <Card className="w-full max-w-lg">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-mec-blue">🔧 QUIZ DE DIAGNÓSTICO ELECTRÓNICO 🔧</h2>
          <p className="text-mec-gray dark:text-gray-300 mt-2">Identifícate para comenzar la evaluación.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <InputGroup label="Nombres completos" icon={<UserIcon className="h-5 w-5 text-mec-gray" />} error={errors.fullName}>
            <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Ej: Juan Carlos" className="w-full bg-transparent focus:outline-none dark:text-white" />
          </InputGroup>
          <InputGroup label="Apellidos completos" icon={<UserIcon className="h-5 w-5 text-mec-gray" />} error={errors.lastName}>
            <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Ej: Pérez Gómez" className="w-full bg-transparent focus:outline-none dark:text-white" />
          </InputGroup>
          <InputGroup label="Número de ID" icon={<IdCardIcon className="h-5 w-5 text-mec-gray" />} error={errors.idNumber}>
            <input type="text" value={idNumber} onChange={(e) => setIdNumber(e.target.value)} placeholder="Ej: 12345678" className="w-full bg-transparent focus:outline-none dark:text-white" />
          </InputGroup>
          
          <div className="flex items-center p-3 border border-mec-blue/20 rounded-lg bg-mec-blue/5 dark:bg-mec-blue/10">
              <GraduationCapIcon className="h-5 w-5 text-mec-gray mr-3"/>
              <span className="text-mec-gray dark:text-gray-300">Código del curso: </span>
              <strong className="ml-2 text-mec-carbon dark:text-white">AUTO-MEC-101</strong>
          </div>

          <button type="submit" disabled={!isFormValid} className="w-full bg-mec-orange text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition-colors disabled:bg-mec-gray disabled:cursor-not-allowed">
            🚀 INICIAR QUIZ
          </button>
        </form>

        <div className="text-center mt-6 text-sm text-mec-gray dark:text-gray-400">
          <p>⏰ Duración: 30 minutos | 📝 20 preguntas | 🎯 70% mínimo para aprobar</p>
        </div>
      </Card>
    </div>
  );
};

interface InputGroupProps {
    label: string;
    icon: React.ReactNode;
    children: React.ReactNode;
    error?: string;
}

const InputGroup: React.FC<InputGroupProps> = ({ label, icon, children, error }) => (
    <div>
        <label className="block text-sm font-medium text-mec-gray dark:text-gray-300 mb-1">{label} *</label>
        <div className={`flex items-center border rounded-lg p-3 ${error ? 'border-mec-red' : 'border-mec-blue/20'}`}>
            <span className="mr-3">{icon}</span>
            {children}
        </div>
        {error && <p className="text-mec-red text-xs mt-1">{error}</p>}
    </div>
);

export default QuizForm;