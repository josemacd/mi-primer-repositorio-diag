import React, { useState, useMemo } from 'react';
import { Question } from '../types';
import { CheckCircleIcon, XCircleIcon } from './Icons';

interface MiniQuizProps {
  questions: Question[];
  onComplete: () => void;
  quizTitle: string;
}

const MiniQuiz: React.FC<MiniQuizProps> = ({ questions, onComplete, quizTitle }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const currentQuestion = questions[currentIndex];
  const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

  const handleSelectAnswer = (answerIndex: number) => {
    if (showFeedback) return;
    setSelectedAnswer(answerIndex);
    if (answerIndex === currentQuestion.correctAnswer) {
      setScore(s => s + 1);
    }
    setShowFeedback(true);
  };

  const handleNext = () => {
    setShowFeedback(false);
    setSelectedAnswer(null);
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(i => i + 1);
    } else {
      setIsFinished(true);
    }
  };
  
  const progressPercentage = ((currentIndex + 1) / questions.length) * 100;

  if (isFinished) {
    return (
        <div className="text-center p-6 animate-fade-in">
            <h3 className="text-2xl font-bold text-mec-blue dark:text-mec-orange mb-4">Repaso Completado</h3>
            <p className="text-lg text-mec-carbon dark:text-white mb-2">Tu puntuación:</p>
            <p className="text-4xl font-bold text-mec-green mb-6">{score} / {questions.length}</p>
            <button
                onClick={onComplete}
                className="w-full bg-mec-blue text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition-colors"
            >
                Volver al Módulo
            </button>
        </div>
    );
  }

  return (
    <div className="p-2 sm:p-6 animate-fade-in">
        <h3 className="text-2xl font-bold text-center text-mec-blue dark:text-mec-orange mb-4">Repaso: {quizTitle}</h3>
        
         <div className="mb-4">
          <div className="flex justify-between items-center mb-2 text-sm text-mec-gray dark:text-gray-300">
            <span>Pregunta {currentIndex + 1} de {questions.length}</span>
          </div>
          <div className="w-full bg-mec-light-gray dark:bg-mec-gray rounded-full h-2.5">
            <div className="bg-mec-orange h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
          </div>
        </div>

      <div className="my-6">
        <p className="text-xl font-semibold text-mec-carbon dark:text-white">
          {currentQuestion.question}
        </p>
      </div>

      <div className="space-y-3">
        {currentQuestion.options.map((option, index) => {
          let buttonClass = 'border-mec-gray/20 bg-white dark:bg-mec-gray/10 hover:bg-mec-blue/5 dark:hover:bg-mec-blue/20';
          if (showFeedback) {
            if (index === currentQuestion.correctAnswer) {
                buttonClass = 'border-mec-green bg-mec-green/10 ring-2 ring-mec-green';
            } else if (index === selectedAnswer) {
                buttonClass = 'border-mec-red bg-mec-red/10 ring-2 ring-mec-red';
            }
          }

          return (
            <button
              key={index}
              onClick={() => handleSelectAnswer(index)}
              disabled={showFeedback}
              className={`w-full text-left p-4 border-2 rounded-lg transition-all flex items-center justify-between ${buttonClass}`}
            >
              <div>
                <span className={`font-bold mr-3`}>
                  {String.fromCharCode(65 + index)}
                </span>
                <span className="text-mec-carbon dark:text-gray-200">{option}</span>
              </div>
              {showFeedback && index === selectedAnswer && (
                isCorrect ? <CheckCircleIcon className="h-6 w-6 text-mec-green" /> : <XCircleIcon className="h-6 w-6 text-mec-red" />
              )}
            </button>
          );
        })}
      </div>
      
      {showFeedback && (
        <div className="mt-8 text-center">
            <button
                onClick={handleNext}
                className="w-full bg-mec-blue text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition-colors"
            >
                {currentIndex < questions.length - 1 ? 'Siguiente Pregunta' : 'Ver Resultados'}
            </button>
        </div>
      )}
    </div>
  );
};

export default MiniQuiz;
