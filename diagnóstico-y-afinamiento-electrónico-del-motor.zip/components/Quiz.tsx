
import React, { useState, useEffect, useCallback } from 'react';
import { Question, Answers } from '../types';
import Card from './shared/Card';
import { ClockIcon, ChevronLeftIcon, ChevronRightIcon } from './Icons';

interface QuizProps {
  questions: Question[];
  onFinish: (answers: Answers, timeTaken: number) => void;
}

const QUIZ_DURATION = 30 * 60; // 30 minutes in seconds

const Quiz: React.FC<QuizProps> = ({ questions, onFinish }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const [timeLeft, setTimeLeft] = useState(QUIZ_DURATION);

  const handleFinish = useCallback(() => {
    const timeTaken = QUIZ_DURATION - timeLeft;
    onFinish(answers, timeTaken);
  }, [answers, onFinish, timeLeft]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime <= 1) {
          clearInterval(timer);
          handleFinish();
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [handleFinish]);

  const handleSelectAnswer = (questionIndex: number, answerIndex: number) => {
    setAnswers((prev) => ({ ...prev, [questionIndex]: answerIndex }));
  };

  const currentQuestion = questions[currentIndex];
  const progressPercentage = ((currentIndex + 1) / questions.length) * 100;

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex justify-center items-center min-h-full p-4 animate-fade-in">
      <Card className="w-full max-w-3xl">
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2 text-sm text-mec-gray dark:text-gray-300">
            <span>Pregunta {currentIndex + 1} de {questions.length}</span>
            <div className={`flex items-center ${timeLeft < 300 ? 'text-mec-red' : 'text-mec-yellow'}`}>
              <ClockIcon className="h-4 w-4 mr-1" />
              <span>{formatTime(timeLeft)}</span>
            </div>
          </div>
          <div className="w-full bg-mec-light-gray dark:bg-mec-gray rounded-full h-2.5">
            <div className="bg-mec-orange h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
          </div>
        </div>
        
        <div className="my-6">
          <p className="text-xl font-semibold text-mec-carbon dark:text-white mb-1">
            <span className="text-mec-blue mr-2">#{currentIndex + 1}</span>
            {currentQuestion.question}
          </p>
          <span className="text-xs px-2 py-1 bg-mec-blue/10 text-mec-blue rounded-full">{currentQuestion.category}</span>
        </div>

        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => {
            const isSelected = answers[currentIndex] === index;
            return (
              <button
                key={index}
                onClick={() => handleSelectAnswer(currentIndex, index)}
                className={`w-full text-left p-4 border-2 rounded-lg transition-all
                  ${isSelected 
                    ? 'border-mec-orange bg-mec-orange/10 ring-2 ring-mec-orange' 
                    : 'border-mec-gray/20 bg-white dark:bg-mec-gray/10 hover:bg-mec-blue/5 dark:hover:bg-mec-blue/20'}`}
              >
                <span className={`font-bold mr-3 ${isSelected ? 'text-mec-orange' : 'text-mec-blue'}`}>
                  {String.fromCharCode(65 + index)}
                </span>
                <span className="text-mec-carbon dark:text-gray-200">{option}</span>
              </button>
            );
          })}
        </div>

        <div className="flex justify-between mt-8">
          <button
            onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
            disabled={currentIndex === 0}
            className="flex items-center bg-mec-gray text-white font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-colors disabled:bg-opacity-50"
          >
            <ChevronLeftIcon className="h-5 w-5 mr-1" />
            Anterior
          </button>
          {currentIndex === questions.length - 1 ? (
            <button
              onClick={handleFinish}
              className="bg-mec-green text-white font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-colors"
            >
              Finalizar Quiz
            </button>
          ) : (
            <button
              onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))}
              disabled={currentIndex === questions.length - 1}
              className="flex items-center bg-mec-blue text-white font-bold py-2 px-4 rounded-lg hover:bg-opacity-90 transition-colors"
            >
              Siguiente
              <ChevronRightIcon className="h-5 w-5 ml-1" />
            </button>
          )}
        </div>
      </Card>
    </div>
  );
};

export default Quiz;
