export enum AppView {
  DASHBOARD,
  MODULE,
  QUIZ_FORM,
  QUIZ_ACTIVE,
  QUIZ_RESULTS,
}

export type ModuleTab = 'Introducción' | 'Componentes' | 'Tipos' | 'Pruebas' | 'Diagnóstico' | 'Consejos';

export enum QuizCategory {
  FUNCTIONING = "Funcionamiento del Sistema",
  SYSTEM_TYPES = "Tipos de Sistemas de Alimentación",
  COMPONENTS = "Componentes y Partes",
  TESTS = "Pruebas y Especificaciones",
  DIAGNOSIS = "Casos de Diagnóstico",
}

export interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  category: QuizCategory;
}

export interface Student {
  fullName: string;
  lastName: string;
  idNumber: string;
  courseCode: string;
}

export type Answers = { [key: number]: number };

export interface QuizResultDetails {
  score: number;
  correctAnswers: number;
  totalQuestions: number;
  timeTaken: number;
  categoryPerformance: { [key in QuizCategory]: { correct: number; total: number } };
}

export interface DiagnosticCaseData {
  id: number;
  title: string;
  symptom: string;
  image?: string;
  tests: {
    name: string;
    tool: string;
    result: string;
  }[];
  diagnoses: string[];
  correctDiagnosisIndex: number;
  conclusion: string;
  solution: string;
}
